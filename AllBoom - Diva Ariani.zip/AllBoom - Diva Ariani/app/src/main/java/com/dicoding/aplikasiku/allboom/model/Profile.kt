package com.dicoding.aplikasiku.allboom.model

data class Profile(
    val photoUrl: String,
    val email: String,
    val name: String
)