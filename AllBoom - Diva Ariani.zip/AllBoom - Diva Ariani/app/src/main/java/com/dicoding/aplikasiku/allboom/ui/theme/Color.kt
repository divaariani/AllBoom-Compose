package com.dicoding.aplikasiku.allboom.ui.theme

import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFCDC7B9)
val Navy = Color(0xFF19378A)